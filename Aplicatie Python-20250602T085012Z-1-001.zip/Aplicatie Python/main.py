# Clasul cu date despre autori
class DateCartiAutori:
    def __init__(self, numeAutor, prenumeAutor, listaCarti):
        self._numeAutor = numeAutor
        self._prenumeAutor = prenumeAutor
        self._listaCarti = listaCarti

# Functia pentru initializarea autorilor deja existenti
def Initializare():
    dateCartiAutori = []
    
    autor1 = DateCartiAutori("Eminescu", "Mihai", ["Luceafărul", "Scrisoarea III"])
    autor2 = DateCartiAutori("Creangă", "Ion", ["Amintiri din copilărie", "Povești"])
    autor3 = DateCartiAutori("Blaga", "Lucian", ["Poemele luminii", "Trilogia culturii"])
    autor4 = DateCartiAutori("Sadoveanu", "Mihail", ["Baltagul", "Frații Jderi"])

    dateCartiAutori.append(autor1)
    dateCartiAutori.append(autor2)
    dateCartiAutori.append(autor3)
    dateCartiAutori.append(autor4)
    
    return dateCartiAutori
    
# Functia pentru adaugarea unui autor nou
def EX1_AdaugareAutor(listaAutori):
    numeAutor = input("Introduceti numele autorului:")
    prenumeAutor = input("Introduceti prenumele autorului:")
    autorRepetat = False
    
    for autor in listaAutori:
        if(autor._numeAutor.lower() == numeAutor.lower() and autor._prenumeAutor.lower() == prenumeAutor.lower()):
            autorRepetat = True
            break
            
    if(autorRepetat):
        print("Autorul dat deja exista")
    else:
        autorNou = DateCartiAutori(numeAutor, prenumeAutor, [])
        listaAutori.append(autorNou)
        print("Autorul a fost inserat\n")
        
# Functia pentru adaugarea catilor pentru un autor      
def EX2_AdaugareCarteAutor(listaAutori):
    numeAutor = input("Introduceti numele autorului: ")
    prenumeAutor = input("Introduceti numele autorului: ")
    autorExistent = False
    
    for autor in listaAutori:
        if numeAutor.lower() == autor._numeAutor.lower() and prenumeAutor.lower() == autor._prenumeAutor.lower():
            autorExistent = True
            autorGasit = autor
            break
    
    if(autorExistent):
        carteNoua = input("Introduceti numele cartii: ")
        autorGasit._listaCarti.append(carteNoua)
        print("Cartea a fost inserata\n")
    else:
        print("Autorul dat nu exista")
        
# Functia pentru actualizarea catilor pentru un autor
def EX3_ActualizareNumeCarte(listaAutori):
    numeAutor = input("Introduceti numele autorului: ")
    prenumeAutor = input("Introduceti numele autorului: ")
    autorExistent = False
    
    for autor in listaAutori:
        if numeAutor.lower() == autor._numeAutor.lower() and prenumeAutor.lower() == autor._prenumeAutor.lower():
            autorExistent = True
            autorGasit = autor
            break
    
    if(autorExistent):
        carteVeche = input("Introduceti numele cartii vechi: ")
        
        if(carteVeche in autor._listaCarti):
            carteNoua = input("Introduceti numele cartii noi: ")
            indexCarte = autorGasit._listaCarti.index(carteVeche)
            autorGasit._listaCarti[indexCarte] = carteNoua;
            print("Cartea a fost actualizata")
        else:
            print("Cartea data nu exista")
    else:
        print("Autorul dat nu exista")
        
# Functia pentru afisarea tuturor autorilor
def EX4_AfisareDateCartiAutori(listaAutori):
    indexAutor = 1
    
    for autor in listaAutori:
        print(indexAutor, " | ", autor._numeAutor, " | ", autor._prenumeAutor, " | ", autor._listaCarti)
        indexAutor += 1
        
# Functia pentru afisarea nr de carti a autorilor
def EX5_AfisareNrCartiAutori(listaAutori):
    
    for autor in listaAutori:
        print(autor._numeAutor, " | ", autor._prenumeAutor, " | ", len(autor._listaCarti))
        
# Functia pentru afisarea nr de carti a autorilor
def EX6_EliminareAutor(listaAutori):
    
    numeAutor = input("Introduceti numele autorului: ")
    prenumeAutor = input("Introduceti numele autorului: ")
    autorExistent = False
    
    for autor in listaAutori:
        if(numeAutor.lower() == autor._numeAutor.lower() and prenumeAutor.lower() == autor._prenumeAutor.lower()):
            autorExistent = True
            autorGasit = autor
            break
    
    if(autorExistent):
        print("Sunteti siguri ca doriti sa stergeti autorul dat?, Y/N")
        raspuns = input("Raspuns: ")
        if(raspuns == "Y"):
            listaAutori.remove(autorGasit)
            print("Autorul a fost eliminat")
        else:
            print("Autorul a ramas nemodificat")
        
# Sectiunea main
listaAutori = Initializare()

while True:
    print("")
    print("1. Adăugați un nou autor (nume + prenume)")
    print("2. Adăugați o carte unui autor existent (fără duplicate, mai multe cărți)")
    print("3. Modificați un titlu de carte existent pentru un autor")
    print("4. Afișați lista autorilor și a cărților acestora")
    print("5. Afișați câte cărți are fiecare autor")
    print("6. Eliminați un autor și toate cărțile sale")
    print("7. Ieșire din program")
    print("")
    
    EX4_AfisareDateCartiAutori(listaAutori)
    print("")
    
    operatiune = int(input("Introduceti numarul operatiunii: "))
    if(operatiune == 1):
        EX1_AdaugareAutor(listaAutori)
    elif(operatiune == 2):
        EX2_AdaugareCarteAutor(listaAutori)
    elif(operatiune == 3):
        EX3_ActualizareNumeCarte(listaAutori)
    elif(operatiune == 4):
        EX4_AfisareDateCartiAutori(listaAutori)
    elif(operatiune == 5):   
        EX5_AfisareNrCartiAutori(listaAutori)
    elif(operatiune == 6): 
        EX6_EliminareAutor(listaAutori)
    elif(operatiune == 7): 
        quit()
    else:
        print("operatiune nevalida")